﻿using CommonLogic.Dtos;
using System.Threading.Tasks;

namespace CommonLogic.Services
{
    public interface IMessageService
    {
        Task<MessageDto> GetMeessageAsync();
    }
}