﻿using AutoMapper;
using CommonLogic.Dtos;
using CommonLogic.Models;
using System.Net.Http;
using System.Threading.Tasks;

namespace CommonLogic.Services
{
    public class MessageService : IMessageService
    {
        private readonly IMapper _mapper;
        private readonly HttpClient _client;

        public MessageService(IMapper mapper, HttpClient client)
        {
            _mapper = mapper;
            _client = client;
        }

        public async Task<MessageDto> GetMeessageAsync()
        {
            var model = new MessageModel { Url = "http://www.google.com" };

            var response = await _client.GetAsync(model.Url);
            model.Result = await response.Content.ReadAsStringAsync();

            return _mapper.Map<MessageDto>(model);
        }
    }
}
