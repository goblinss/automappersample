﻿namespace CommonLogic.Models
{
    public class MessageModel
    {
        public string Url { get; set; }
        public string Result { get; set; }
    }
}
