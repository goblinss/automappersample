﻿namespace CommonLogic.Dtos
{
    public class MessageDto
    {
        public string Url { get; set; }
        public string Result { get; set; }
    }
}
