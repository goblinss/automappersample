using CommonLogic.Services;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using System.IO;
using System.Threading.Tasks;

namespace FunctionAppV3
{
    public class BlobTriggerFunc
    {
        private readonly IMessageService _messageService;
        
        public BlobTriggerFunc(IMessageService messageService)
        {
            _messageService = messageService;
        }

        [FunctionName("BlobTriggerFunc")]
        public async Task Run([BlobTrigger("samples-workitems/{name}", Connection = "AzureWebJobsStorage")]Stream myBlob, string name, ILogger log)
        {
            var dto = await _messageService.GetMeessageAsync();

            log.LogInformation($"C# Blob trigger function Processed blob\n Name:{name} \n Size: {myBlob.Length} Bytes. Message {dto.Result}");
        }
    }
}
