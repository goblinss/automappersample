﻿using AutoMapper;
using CommonLogic.Dtos;
using CommonLogic.Models;

namespace FunctionAppV3
{
    public class FunctionsProfile : Profile
    {
        public FunctionsProfile()
        {
            CreateMap<MessageDto, MessageModel>();
            CreateMap<MessageModel, MessageDto>();
        }
    }
}
