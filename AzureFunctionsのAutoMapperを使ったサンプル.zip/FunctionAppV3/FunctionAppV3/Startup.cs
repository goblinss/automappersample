﻿using AutoMapper;
using CommonLogic.Services;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;

[assembly: FunctionsStartup(typeof(FunctionAppV3.Startup))]

namespace FunctionAppV3
{
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            builder.Services.AddAutoMapper(this.GetType().Assembly);
            builder.Services.AddHttpClient(); 
            builder.Services.AddTransient<IMessageService, MessageService>();
        }
    }
}